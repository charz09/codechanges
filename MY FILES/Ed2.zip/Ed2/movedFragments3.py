
testInt1 = 0
testInt2 = 0

def fragmentFunction1():
	pass

def fragmentFunction2():
	pass

testString1 = ""
testString2 = ""