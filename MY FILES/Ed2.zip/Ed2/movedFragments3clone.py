
testInt2 = 0
testInt1 = 0

def fragmentFunction2():
	pass

def fragmentFunction1():
	pass

testString2 = ""
testString1 = ""
