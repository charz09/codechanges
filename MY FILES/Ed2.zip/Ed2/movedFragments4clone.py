
def storeFinder(store):
	if store == "B&Q":
		print("https://www.diy.com/")
	elif store == "Screwfix":
		print("https://www.screwfix.com/")
	elif store == "Homebase":
		print("https://www.homebase.co.uk/")
	elif store == "Currys":
		print("https://www.currys.co.uk/gbuk/index.html")
	else:
		print("Could not find store.")