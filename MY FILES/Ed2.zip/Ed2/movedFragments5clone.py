class movedFragments5:
	def __init__(self, name, jobTitle, DOB):
		self.jobTitle = jobTitle
		self.name = name
		self.DOB = DOB

test1 = movedFragments5("GOB", "Illusionist", "14/01/1969")