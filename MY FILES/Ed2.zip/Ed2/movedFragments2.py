

a = "First String"
b = "Second String"
c = "Third String"

def function1(firstString):
	for i in firstString:
		print(i)

def function2(secondString):
	if type(secondString) == str:
		print("Success.")

def function3(thirdString):
	print("Do nothing.")