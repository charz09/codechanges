
count = 0
while count == 0:
	print("Is the number higher or lower than 42?")
	number = input()
	if number <= 42:
		print("Lower.")
	else:
		print("Higher")
