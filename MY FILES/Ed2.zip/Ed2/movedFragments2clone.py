c = "Third String"
a = "First String"
b = "Second String"


def function2(secondString):
	if type(secondString) == str:
		print("Success.")

def function1(firstString):
	for i in firstString:
		print(i)


def function3(thirdString):
	print("Do nothing.")