import java.io.PrintStream;

public class main
{
  public static void main(String[] paramArrayOfString)
  {
    paramArrayOfString = 1;
    for (String[] arrayOfString = 1; arrayOfString <= 10; arrayOfString++)
      paramArrayOfString *= arrayOfString;
    System.out.println(paramArrayOfString);
  }
}

/* Location:           C:\Users\Admin\Desktop\totest\Main-JARExport\main-jar.jar
 * Qualified Name:     main
 * JD-Core Version:    0.6.0
 */