
public class main {
	public static void main(String[] args) {
		int ret = 1;
		for (int i = 1; i <= 10; ++i) ret *= i;
		System.out.println(ret);
	}
}
