int main()
{
   int i, fac = 1;
 
   for( i = 1 ; i <= 10 ; i++ )
         fac = fac*i;
 
   printf("%d\n",fac);

   return 0;
}