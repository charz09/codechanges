package de.jplag.java;

public class Language {

}
