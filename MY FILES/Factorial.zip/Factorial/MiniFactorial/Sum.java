Best product according to LeastExpensiveStrategy:
Vauxhall Nova
Best product according to MostPracticalStrategy:
Skoda Octavia
