
public class main {
	
	public static void main(String[] args) {
		System.out.println(factorial10());
	}
	
	public static int factorial10()
    {
		int ret = 1;
		ret *= 2;
		ret *= 3;
		ret *= 4;
		ret *= 5;
		ret *= 6;
		ret *= 7;
		ret *= 8;
		ret *= 9;
		ret *= 10;
        return ret;
    }
}
